<?php

namespace Training\Test\Block;

class Main extends \Magento\Framework\View\Element\Template{
    
    
}