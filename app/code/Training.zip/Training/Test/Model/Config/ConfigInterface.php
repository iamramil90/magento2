<?php
namespace Training\Test\Model\Config;

interface ConfigInterface{
    
    public function getMyNodeInfo();
}

?>